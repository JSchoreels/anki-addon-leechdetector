import re

RE_CUSTOMSEARCH = r'^leeches:(all|active|recovering|recovered)\((.*?)\)$'
RE_CUSTOMSEARCH_GROUP_TYPE = 1
RE_CUSTOMSEARCH_GROUP_ARGS = 2